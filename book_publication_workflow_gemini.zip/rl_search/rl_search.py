def rl_based_retrieval(query, versions):
    for version in versions:
        if query.lower() in version.lower():
            return version
    return "No matching version found."
