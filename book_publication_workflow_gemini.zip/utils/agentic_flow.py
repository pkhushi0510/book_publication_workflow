def flow_pipeline(original_content, writer, reviewer, human):
    spun = writer(original_content)
    reviewed = reviewer(spun)
    final = human(reviewed)
    return final
