import chromadb

def save_version(content, version_name):
    client = chromadb.Client()
    collection = client.get_or_create_collection("book_versions")
    collection.add(
        documents=[content],
        ids=[version_name],
        metadatas=[{"version": version_name}]
    )

def get_version(version_name):
    client = chromadb.Client()
    collection = client.get_collection("book_versions")
    return collection.get(ids=[version_name])
