from scraping.fetch_chapter import fetch_content_and_screenshot
from ai_processing.ai_writer import ai_writer_spin
from ai_processing.ai_reviewer import ai_reviewer_review
from human_loop.human_iteration import human_feedback_loop
from versioning.version_manager import save_version
from utils.agentic_flow import flow_pipeline

if __name__ == "__main__":
    url = "https://en.wikisource.org/wiki/The_Gates_of_Morning/Book_1/Chapter_1"

    print("Fetching content...")
    content = fetch_content_and_screenshot(url)

    print("Running agentic pipeline...")
    final_version = flow_pipeline(content, ai_writer_spin, ai_reviewer_review, human_feedback_loop)

    print("Saving version...")
    save_version(final_version, version_name="chapter_1_final")

    print("✅ Workflow completed.")
