import google.generativeai as genai
from dotenv import load_dotenv
import os

load_dotenv()
api_key = os.getenv("GOOGLE_API_KEY")
genai.configure(api_key=api_key)

model = genai.GenerativeModel("gemini-pro")

def ai_writer_spin(content):
    prompt = f"Rewrite the following book content to make it more engaging and modern:\n\n{content}"
    response = model.generate_content(prompt)
    return response.text
